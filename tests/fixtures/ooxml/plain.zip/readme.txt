apenas um zip comum, sem OOXML
